# Strategy replay records

The JSON files contain weekly lineups, transfers, chips, points and solver diagnostics.
All four runs start with the same squad. Input checksums are in `inputs-manifest.json`.
The `source/` folder contains the planner revision used by the final transfer runs.
